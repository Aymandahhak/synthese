import { ValidationSessions as ValidationSessionsComponent } from "@/components/validation-sessions"

const ValidationSessions = () => {
  return <ValidationSessionsComponent />
}

export default ValidationSessions
