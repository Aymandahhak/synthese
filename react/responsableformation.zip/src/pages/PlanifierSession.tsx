import { PlanifierSessionForm } from "@/components/planifier-session-form"

const PlanifierSession = () => {
  return <PlanifierSessionForm />
}

export default PlanifierSession
