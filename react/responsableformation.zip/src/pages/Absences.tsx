import { AbsencesPage } from "@/components/absences-page"

const Absences = () => {
  return <AbsencesPage />
}

export default Absences
