import { DocumentsPage } from "@/components/documents-page"

const Documents = () => {
  return <DocumentsPage />
}

export default Documents
