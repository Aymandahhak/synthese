"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useNavigate } from "react-router-dom"

const Dashboard = () => {
  const navigate = useNavigate()

  // Formation data
  const formations = [
    {
      id: "1",
      name: "Introduction au Marketing Digital",
      status: "validated",
      image: "/formations/marketing-digital.jpg",
    },
    {
      id: "2",
      name: "Développement Web Avancé",
      status: "pending",
      image: "/formations/web-dev.jpg",
    },
    {
      id: "3",
      name: "Gestion de Projet Agile",
      status: "canceled",
      image: "/formations/agile.jpg",
    },
    {
      id: "4",
      name: "Finance pour non-financiers",
      status: "validated",
      image: "/formations/finance.jpg",
    },
    {
      id: "5",
      name: "Techniques de vente avancées",
      status: "pending",
      image: "/formations/sales.jpg",
    },
    {
      id: "6",
      name: "Leadership et Management d'équipe",
      status: "validated",
      image: "/formations/leadership.jpg",
    },
  ]

  return (
    <>
      <div className="mb-12 grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Video Section with Créer Formation button */}
        <div className="relative overflow-hidden rounded-[24px] h-[250px] border border-[#415444]/10 group">
          <div className="absolute inset-0 bg-gradient-to-r from-[#415444]/80 to-[#415444]/60 z-10"></div>
          <div
            className="absolute inset-0 bg-cover bg-center z-0"
            style={{
              backgroundImage: "url('/backgrounds/formation-bg.jpg')",
              backgroundSize: "cover",
            }}
          ></div>
          <div className="absolute inset-0 flex flex-col items-center justify-center z-20 text-white text-center p-6">
            <h3 className="text-3xl font-bold mb-2">Une nouvelle ère de formation</h3>
            <p className="mb-6 max-w-md">
              Créez des formations personnalisées pour répondre aux besoins spécifiques de votre équipe
            </p>
            <Button className="bg-[#415444] hover:bg-[#415444]/90 border-2 border-white">Créer Formation</Button>
          </div>
        </div>

        {/* Video Section with Planifier Session button */}
        <div className="relative overflow-hidden rounded-[24px] h-[250px] border border-[#415444]/10 group">
          <div className="absolute inset-0 bg-gradient-to-r from-[#338838]/70 to-[#338838]/50 z-10"></div>
          <div
            className="absolute inset-0 bg-cover bg-center z-0"
            style={{
              backgroundImage: "url('/backgrounds/session-bg.jpg')",
              backgroundSize: "cover",
            }}
          ></div>
          <div className="absolute inset-0 flex flex-col items-center justify-center z-20 text-white text-center p-6">
            <h3 className="text-3xl font-bold mb-2">Planifiez vos sessions</h3>
            <p className="mb-6 max-w-md">Organisez et gérez efficacement vos sessions de formation</p>
            <Button
              className="bg-[#338838] hover:bg-[#338838]/90 border-2 border-white"
              onClick={() => navigate("/planifier")}
            >
              Planifier Session
            </Button>
          </div>
        </div>
      </div>

      <div className="mb-8 flex items-center justify-between">
        <h3 className="text-2xl font-semibold">Liste des Formations</h3>
        <Button variant="link">Voir Tout</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {formations.map((formation) => (
          <Card
            key={formation.id}
            className="group border-0 bg-[#e0e5ce] rounded-[24px] overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
          >
            <CardHeader className="p-0 relative">
              <div className="absolute inset-0 bg-black/40 opacity-0 transition-opacity group-hover:opacity-100 z-10" />
              <Button className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 opacity-0 transform scale-95 transition-all group-hover:opacity-100 group-hover:scale-100 bg-white text-black hover:bg-white/90">
                Quick View
              </Button>
              <img
                src={formation.image || "/placeholder.svg"}
                alt={formation.name}
                className="h-[280px] w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div>
                <h4 className="text-lg font-semibold mb-1 line-clamp-1">{formation.name}</h4>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Badge
                    variant="outline"
                    className={
                      formation.status === "validated"
                        ? "bg-green-100 text-green-800 hover:bg-green-100 border-green-200"
                        : formation.status === "pending"
                          ? "bg-yellow-100 text-yellow-800 hover:bg-yellow-100 border-yellow-200"
                          : "bg-red-100 text-red-800 hover:bg-red-100 border-red-200"
                    }
                  >
                    {formation.status === "validated"
                      ? "Validée"
                      : formation.status === "pending"
                        ? "En attente"
                        : "Annulée"}
                  </Badge>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="rounded-full hover:bg-[#415444] hover:text-white transition-colors"
                >
                  View Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  )
}

export default Dashboard
