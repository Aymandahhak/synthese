import { SessionsList as SessionsListComponent } from "@/components/sessions-list"

const SessionsList = () => {
  return <SessionsListComponent />
}

export default SessionsList
