import { LogisticsPage } from "@/components/logistics-page"

const Logistics = () => {
  return <LogisticsPage />
}

export default Logistics
