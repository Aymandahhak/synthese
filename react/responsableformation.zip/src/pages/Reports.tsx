import { ReportsPage } from "@/components/reports-page"

const Reports = () => {
  return <ReportsPage />
}

export default Reports
