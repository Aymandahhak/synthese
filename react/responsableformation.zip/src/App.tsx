import { Routes, Route } from "react-router-dom"
import Layout from "./components/Layout"
import Dashboard from "./pages/Dashboard"
import PlanifierSession from "./pages/PlanifierSession"
import SessionsList from "./pages/SessionsList"
import ValidationSessions from "./pages/ValidationSessions"
import Absences from "./pages/Absences"
import Documents from "./pages/Documents"
import Logistics from "./pages/Logistics"
import Reports from "./pages/Reports"
import { Toaster } from "./components/ui/toaster"

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="planifier" element={<PlanifierSession />} />
          <Route path="sessions" element={<SessionsList />} />
          <Route path="validation" element={<ValidationSessions />} />
          <Route path="absences" element={<Absences />} />
          <Route path="documents" element={<Documents />} />
          <Route path="logistics" element={<Logistics />} />
          <Route path="rapports" element={<Reports />} />
        </Route>
      </Routes>
      <Toaster />
    </>
  )
}

export default App
