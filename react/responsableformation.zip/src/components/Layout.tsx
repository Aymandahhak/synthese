"use client"
import { Outlet, useLocation, useNavigate } from "react-router-dom"
import { BarChart, Bell, Calendar, CheckSquare, FileText, Home, ListChecks, LogOut, Search, UserX } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const Layout = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const currentPath = location.pathname === "/" ? "dashboard" : location.pathname.substring(1)

  const navigateTo = (path: string) => {
    if (path === "dashboard") {
      navigate("/")
    } else {
      navigate(`/${path}`)
    }
  }

  return (
    <div className="flex min-h-screen bg-[#fcfdfd]">
      {/* Sidebar */}
      <aside className="w-64 border-r px-6 py-8">
        <div className="mb-8 flex justify-center">
          <div className="h-10 w-10 rounded-full bg-[#e0e5ce] flex items-center justify-center">
            <span className="text-[#415444] font-bold">TS</span>
          </div>
        </div>
        <nav className="space-y-6">
          <button
            onClick={() => navigateTo("dashboard")}
            className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 transition-colors ${
              currentPath === "dashboard" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <Home className="h-5 w-5" />
            Dashboard
          </button>
          <button
            onClick={() => navigateTo("planifier")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPath === "planifier" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <Calendar className="h-5 w-5" />
            Planifier Session
          </button>
          <button
            onClick={() => navigateTo("sessions")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPath === "sessions" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <ListChecks className="h-5 w-5" />
            Liste Sessions
          </button>
          <button
            onClick={() => navigateTo("validation")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPath === "validation" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <CheckSquare className="h-5 w-5" />
            Validation
          </button>
          <button
            onClick={() => navigateTo("absences")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPath === "absences" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <UserX className="h-5 w-5" />
            Absences
          </button>
          <button
            onClick={() => navigateTo("documents")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPath === "documents" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <FileText className="h-5 w-5" />
            Documents
          </button>
          <button
            onClick={() => navigateTo("logistics")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPath === "logistics" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <Home className="h-5 w-5" />
            Hébergements
          </button>
          <button
            onClick={() => navigateTo("rapports")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPath === "rapports" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <BarChart className="h-5 w-5" />
            Rapports
          </button>
          <button className="flex w-full items-center gap-3 px-3 py-2 text-red-500 transition-colors hover:text-red-600">
            <LogOut className="h-5 w-5" />
            Logout
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 px-8 py-8">
        <header className="mb-8">
          <div className="flex items-center justify-between border-b pb-4 mb-4">
            <div className="flex items-center gap-8">
              <img src="/logo.png" alt="Fashion Store" className="h-10 w-auto" />
              <nav className="flex items-center gap-6">
                <a href="#" className="font-medium text-[#415444]">
                  Home
                </a>
                <a href="#" className="font-medium text-gray-500 hover:text-[#415444]">
                  Profile
                </a>
                <a href="#" className="font-medium text-gray-500 hover:text-[#415444]">
                  About
                </a>
              </nav>
            </div>
            <div className="flex items-center gap-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input className="w-64 pl-10" placeholder="Search destination" />
              </div>
              <Button size="icon" variant="ghost">
                <Bell className="h-5 w-5" />
              </Button>
              <Avatar className="w-10 h-10">
                <AvatarImage src="/avatar.jpg" alt="User avatar" />
                <AvatarFallback>NA</AvatarFallback>
              </Avatar>
            </div>
          </div>
          <div className="space-y-1">
            <h2 className="text-2xl font-semibold">
              Hi, Dollar! <span className="ml-1">👋</span>
            </h2>
            <p className="text-gray-500">Welcome Back</p>
          </div>
        </header>

        <Outlet />
      </main>
    </div>
  )
}

export default Layout
