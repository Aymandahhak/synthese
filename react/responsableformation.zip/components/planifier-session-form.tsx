"use client"

import { useState } from "react"
import { Calendar, Check, MapPin } from "lucide-react"
import { useForm } from "react-hook-form"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

// Sample data for trainers
const trainers = [
  {
    id: "1",
    name: "Hannah Laurent",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-6UteJvjmo7I9YCqO5hu0HHO1qGVjpm.png",
    expertise: "Marketing Digital",
  },
  {
    id: "2",
    name: "Thomas Martin",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-6UteJvjmo7I9YCqO5hu0HHO1qGVjpm.png",
    expertise: "Développement Web",
  },
  {
    id: "3",
    name: "Sophie Dubois",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-6UteJvjmo7I9YCqO5hu0HHO1qGVjpm.png",
    expertise: "Ressources Humaines",
  },
  {
    id: "4",
    name: "Jean Petit",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-6UteJvjmo7I9YCqO5hu0HHO1qGVjpm.png",
    expertise: "Finance",
  },
]

// Sample data for locations
const locations = [
  { id: "1", name: "Salle de conférence A", capacity: 30 },
  { id: "2", name: "Salle de formation B", capacity: 20 },
  { id: "3", name: "Amphithéâtre C", capacity: 100 },
  { id: "4", name: "Salle de réunion D", capacity: 15 },
]

// Sample data for themes
const themes = [
  { id: "1", name: "Développement personnel" },
  { id: "2", name: "Marketing digital" },
  { id: "3", name: "Gestion de projet" },
  { id: "4", name: "Ressources humaines" },
  { id: "5", name: "Finance et comptabilité" },
]

export function PlanifierSessionForm() {
  const [selectedTrainers, setSelectedTrainers] = useState<string[]>([])
  const [startDate, setStartDate] = useState<Date | undefined>(new Date())
  const [endDate, setEndDate] = useState<Date | undefined>(new Date())
  const [isSubmitting, setIsSubmitting] = useState(false)

  const form = useForm({
    defaultValues: {
      title: "",
      theme: "",
      location: "",
      resources: "",
    },
  })

  const onSubmit = async (data: any) => {
    setIsSubmitting(true)

    // Combine all form data
    const sessionData = {
      ...data,
      trainers: selectedTrainers,
      startDate: startDate?.toISOString(),
      endDate: endDate?.toISOString(),
    }

    try {
      // Simulate API call
      console.log("Submitting session data:", sessionData)

      // In a real app, you would make an API call like this:
      // const response = await fetch('https://your-api.com/sessions', {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   body: JSON.stringify(sessionData),
      // });

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Session planifiée avec succès",
        description: `La session "${data.title}" a été créée.`,
      })

      // Reset form
      form.reset()
      setSelectedTrainers([])
      setStartDate(new Date())
      setEndDate(new Date())
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la création de la session.",
        variant: "destructive",
      })
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const toggleTrainer = (trainerId: string) => {
    setSelectedTrainers((prev) =>
      prev.includes(trainerId) ? prev.filter((id) => id !== trainerId) : [...prev, trainerId],
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Planifier une Session</h2>
        <p className="text-gray-500">Créez une nouvelle session de formation</p>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Title */}
              <FormField
                control={form.control}
                name="title"
                rules={{ required: "Le titre est requis" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Titre de la session</FormLabel>
                    <FormControl>
                      <Input placeholder="Entrez le titre de la session" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Theme/Topic */}
              <FormField
                control={form.control}
                name="theme"
                rules={{ required: "Le thème est requis" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Thème</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionnez un thème" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {themes.map((theme) => (
                          <SelectItem key={theme.id} value={theme.id}>
                            {theme.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Dates */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Start Date */}
              <FormItem>
                <FormLabel>Date de début</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className="w-full pl-3 text-left font-normal flex justify-between items-center"
                      >
                        {startDate ? startDate.toLocaleDateString() : <span>Sélectionnez une date</span>}
                        <Calendar className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <CalendarComponent mode="single" selected={startDate} onSelect={setStartDate} initialFocus />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>

              {/* End Date */}
              <FormItem>
                <FormLabel>Date de fin</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className="w-full pl-3 text-left font-normal flex justify-between items-center"
                      >
                        {endDate ? endDate.toLocaleDateString() : <span>Sélectionnez une date</span>}
                        <Calendar className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <CalendarComponent
                      mode="single"
                      selected={endDate}
                      onSelect={setEndDate}
                      initialFocus
                      disabled={(date) => (startDate ? date < startDate : false)}
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            </div>

            {/* Location */}
            <FormField
              control={form.control}
              name="location"
              rules={{ required: "Le lieu est requis" }}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Lieu / Site</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionnez un lieu" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {locations.map((location) => (
                        <SelectItem key={location.id} value={location.id}>
                          <div className="flex items-center">
                            <MapPin className="mr-2 h-4 w-4" />
                            <span>{location.name}</span>
                            <span className="ml-2 text-gray-500 text-sm">(Capacité: {location.capacity})</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Trainers */}
            <div>
              <FormLabel>Formateurs</FormLabel>
              <FormDescription>Sélectionnez un ou plusieurs formateurs pour cette session</FormDescription>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                {trainers.map((trainer) => (
                  <div
                    key={trainer.id}
                    className={`flex items-center p-3 rounded-lg border cursor-pointer transition-colors ${
                      selectedTrainers.includes(trainer.id)
                        ? "border-[#415444] bg-[#e0e5ce]/50"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                    onClick={() => toggleTrainer(trainer.id)}
                  >
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src={trainer.image || "/placeholder.svg"} alt={trainer.name} />
                      <AvatarFallback>{trainer.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium">{trainer.name}</p>
                      <p className="text-sm text-gray-500">{trainer.expertise}</p>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                        selectedTrainers.includes(trainer.id) ? "bg-[#415444] border-[#415444]" : "border-gray-300"
                      }`}
                    >
                      {selectedTrainers.includes(trainer.id) && <Check className="h-3 w-3 text-white" />}
                    </div>
                  </div>
                ))}
              </div>
              {selectedTrainers.length === 0 && (
                <p className="text-sm text-red-500 mt-2">Veuillez sélectionner au moins un formateur</p>
              )}
            </div>

            {/* Resources */}
            <FormField
              control={form.control}
              name="resources"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ressources nécessaires</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Décrivez les ressources nécessaires pour cette session..."
                      className="min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Submit Button */}
            <Button
              type="submit"
              className="bg-[#415444] hover:bg-[#415444]/90 w-full md:w-auto"
              disabled={isSubmitting || selectedTrainers.length === 0}
            >
              {isSubmitting ? "Création en cours..." : "Créer la session"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  )
}
