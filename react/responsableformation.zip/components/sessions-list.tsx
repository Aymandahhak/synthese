"use client"

import { useState } from "react"
import { Calendar, ChevronLeft, ChevronRight, Edit, Eye, Filter, MoreHorizontal, Trash2 } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"

// Sample data for sessions
const sessionsData = [
  {
    id: "1",
    title: "Introduction au Marketing Digital",
    startDate: "2023-05-15T09:00:00",
    endDate: "2023-05-15T17:00:00",
    status: "validated",
    participants: 18,
    location: "Salle de conférence A",
    trainer: "Hannah Laurent",
  },
  {
    id: "2",
    title: "Développement Web Avancé",
    startDate: "2023-05-20T10:00:00",
    endDate: "2023-05-22T16:00:00",
    status: "validated",
    participants: 12,
    location: "Salle de formation B",
    trainer: "Thomas Martin",
  },
  {
    id: "3",
    title: "Gestion de Projet Agile",
    startDate: "2023-05-25T09:30:00",
    endDate: "2023-05-26T17:30:00",
    status: "pending",
    participants: 20,
    location: "Amphithéâtre C",
    trainer: "Sophie Dubois",
  },
  {
    id: "4",
    title: "Finance pour non-financiers",
    startDate: "2023-06-05T09:00:00",
    endDate: "2023-06-06T17:00:00",
    status: "pending",
    participants: 15,
    location: "Salle de réunion D",
    trainer: "Jean Petit",
  },
  {
    id: "5",
    title: "Techniques de vente avancées",
    startDate: "2023-06-12T09:00:00",
    endDate: "2023-06-12T17:00:00",
    status: "validated",
    participants: 25,
    location: "Salle de conférence A",
    trainer: "Marie Leroy",
  },
  {
    id: "6",
    title: "Leadership et Management d'équipe",
    startDate: "2023-06-15T09:00:00",
    endDate: "2023-06-16T17:00:00",
    status: "validated",
    participants: 15,
    location: "Salle de formation B",
    trainer: "Pierre Durand",
  },
  {
    id: "7",
    title: "Excel pour les analystes",
    startDate: "2023-06-20T09:00:00",
    endDate: "2023-06-21T17:00:00",
    status: "pending",
    participants: 10,
    location: "Salle de réunion D",
    trainer: "Hannah Laurent",
  },
  {
    id: "8",
    title: "Communication efficace",
    startDate: "2023-06-25T09:00:00",
    endDate: "2023-06-25T17:00:00",
    status: "validated",
    participants: 22,
    location: "Amphithéâtre C",
    trainer: "Sophie Dubois",
  },
  {
    id: "9",
    title: "Cybersécurité pour tous",
    startDate: "2023-07-03T09:00:00",
    endDate: "2023-07-04T17:00:00",
    status: "pending",
    participants: 18,
    location: "Salle de formation B",
    trainer: "Thomas Martin",
  },
  {
    id: "10",
    title: "Design Thinking",
    startDate: "2023-07-10T09:00:00",
    endDate: "2023-07-11T17:00:00",
    status: "validated",
    participants: 16,
    location: "Salle de conférence A",
    trainer: "Marie Leroy",
  },
]

export function SessionsList() {
  const [sessions, setSessions] = useState(sessionsData)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [startDateFilter, setStartDateFilter] = useState<Date | undefined>(undefined)
  const [endDateFilter, setEndDateFilter] = useState<Date | undefined>(undefined)
  const [currentPage, setCurrentPage] = useState(1)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [sessionToDelete, setSessionToDelete] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isFiltersOpen, setIsFiltersOpen] = useState(false)

  const itemsPerPage = 6

  // Apply filters
  const filteredSessions = sessions.filter((session) => {
    // Search query filter
    const matchesSearch =
      session.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.trainer.toLowerCase().includes(searchQuery.toLowerCase())

    // Status filter
    const matchesStatus = statusFilter === "all" || session.status === statusFilter

    // Date range filter
    let matchesDateRange = true
    if (startDateFilter) {
      const sessionStartDate = new Date(session.startDate)
      matchesDateRange = sessionStartDate >= startDateFilter
    }
    if (endDateFilter && matchesDateRange) {
      const sessionEndDate = new Date(session.endDate)
      matchesDateRange = sessionEndDate <= endDateFilter
    }

    return matchesSearch && matchesStatus && matchesDateRange
  })

  // Pagination
  const totalPages = Math.ceil(filteredSessions.length / itemsPerPage)
  const paginatedSessions = filteredSessions.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
  }

  const handleDeleteSession = (sessionId: string) => {
    setSessionToDelete(sessionId)
    setIsDeleteDialogOpen(true)
  }

  const confirmDelete = () => {
    if (!sessionToDelete) return

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setSessions(sessions.filter((session) => session.id !== sessionToDelete))
      setIsDeleteDialogOpen(false)
      setSessionToDelete(null)
      setIsLoading(false)

      toast({
        title: "Session supprimée",
        description: "La session a été supprimée avec succès.",
      })
    }, 1000)
  }

  const resetFilters = () => {
    setSearchQuery("")
    setStatusFilter("all")
    setStartDateFilter(undefined)
    setEndDateFilter(undefined)
    setCurrentPage(1)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString()
  }

  const formatDateRange = (startDate: string, endDate: string) => {
    const start = new Date(startDate)
    const end = new Date(endDate)

    // If same day
    if (start.toDateString() === end.toDateString()) {
      return `${start.toLocaleDateString()}`
    }

    // Different days
    return `${start.toLocaleDateString()} - ${end.toLocaleDateString()}`
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Liste des Sessions</h2>
          <p className="text-gray-500">Gérez toutes vos sessions de formation</p>
        </div>
        <Button className="bg-[#415444] hover:bg-[#415444]/90">Nouvelle Session</Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="relative w-full md:w-auto">
          <Input
            placeholder="Rechercher par titre ou formateur..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full md:w-80"
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <Popover open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                Filtres
                {(statusFilter !== "all" || startDateFilter || endDateFilter) && (
                  <Badge className="ml-1 bg-[#415444] text-white h-5 w-5 p-0 flex items-center justify-center rounded-full">
                    !
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80">
              <div className="space-y-4">
                <h4 className="font-medium">Filtrer les sessions</h4>

                <div className="space-y-2">
                  <Label htmlFor="status">Statut</Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Tous les statuts" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous les statuts</SelectItem>
                      <SelectItem value="pending">En attente</SelectItem>
                      <SelectItem value="validated">Validée</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Date de début</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal">
                        <Calendar className="mr-2 h-4 w-4" />
                        {startDateFilter ? (
                          formatDate(startDateFilter.toISOString())
                        ) : (
                          <span>Sélectionner une date</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={startDateFilter}
                        onSelect={setStartDateFilter}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label>Date de fin</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal">
                        <Calendar className="mr-2 h-4 w-4" />
                        {endDateFilter ? formatDate(endDateFilter.toISOString()) : <span>Sélectionner une date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={endDateFilter}
                        onSelect={setEndDateFilter}
                        initialFocus
                        disabled={(date) => (startDateFilter ? date < startDateFilter : false)}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="flex justify-between pt-2">
                  <Button variant="outline" size="sm" onClick={resetFilters}>
                    Réinitialiser
                  </Button>
                  <Button
                    size="sm"
                    className="bg-[#415444] hover:bg-[#415444]/90"
                    onClick={() => setIsFiltersOpen(false)}
                  >
                    Appliquer
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>

      <Card>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[300px]">Titre de la session</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead className="text-center">Participants</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedSessions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center">
                    Aucune session trouvée.
                  </TableCell>
                </TableRow>
              ) : (
                paginatedSessions.map((session) => (
                  <TableRow key={session.id}>
                    <TableCell className="font-medium">
                      <div>
                        {session.title}
                        <div className="text-xs text-gray-500 mt-1">Formateur: {session.trainer}</div>
                      </div>
                    </TableCell>
                    <TableCell>{formatDateRange(session.startDate, session.endDate)}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={
                          session.status === "validated"
                            ? "bg-green-100 text-green-800 hover:bg-green-100 border-green-200"
                            : "bg-yellow-100 text-yellow-800 hover:bg-yellow-100 border-yellow-200"
                        }
                      >
                        {session.status === "validated" ? "Validée" : "En attente"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">{session.participants}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Ouvrir le menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem className="cursor-pointer">
                            <Eye className="mr-2 h-4 w-4" />
                            <span>Voir les détails</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem className="cursor-pointer">
                            <Edit className="mr-2 h-4 w-4" />
                            <span>Modifier</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="cursor-pointer text-red-600 focus:text-red-600"
                            onClick={() => handleDeleteSession(session.id)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            <span>Supprimer</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            Affichage de {(currentPage - 1) * itemsPerPage + 1} à{" "}
            {Math.min(currentPage * itemsPerPage, filteredSessions.length)} sur {filteredSessions.length} sessions
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Page précédente</span>
            </Button>
            <div className="flex items-center">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  size="sm"
                  className={`h-8 w-8 p-0 ${currentPage === page ? "bg-[#415444] hover:bg-[#415444]/90" : ""}`}
                  onClick={() => handlePageChange(page)}
                >
                  {page}
                </Button>
              ))}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              <ChevronRight className="h-4 w-4" />
              <span className="sr-only">Page suivante</span>
            </Button>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer la suppression</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer cette session ? Cette action ne peut pas être annulée.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)} disabled={isLoading}>
              Annuler
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={isLoading}>
              {isLoading ? (
                <>
                  <Skeleton className="h-4 w-4 rounded-full mr-2" />
                  Suppression...
                </>
              ) : (
                "Supprimer"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
