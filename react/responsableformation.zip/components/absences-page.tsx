import { ChevronRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"

// Sample data for absences
const people = [
  {
    id: "1",
    name: "Hannah Laurent",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9.png",
    department: "Marketing",
    absenceType: "Congé maladie",
    startDate: "2023-04-15",
    endDate: "2023-04-20",
  },
  {
    id: "2",
    name: "Thomas Martin",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9.png",
    department: "Développement",
    absenceType: "Congé annuel",
    startDate: "2023-04-10",
    endDate: "2023-04-17",
  },
  {
    id: "3",
    name: "Sophie Dubois",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9.png",
    department: "Ressources Humaines",
    absenceType: "Formation",
    startDate: "2023-04-18",
    endDate: "2023-04-22",
  },
  {
    id: "4",
    name: "Jean Petit",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9.png",
    department: "Finance",
    absenceType: "Congé sans solde",
    startDate: "2023-04-05",
    endDate: "2023-04-15",
  },
  {
    id: "5",
    name: "Marie Leroy",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9.png",
    department: "Design",
    absenceType: "Congé maladie",
    startDate: "2023-04-12",
    endDate: "2023-04-14",
  },
  {
    id: "6",
    name: "Pierre Durand",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capturjje.PNG-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9.png",
    department: "Ventes",
    absenceType: "Congé annuel",
    startDate: "2023-04-20",
    endDate: "2023-04-30",
  },
]

export function AbsencesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Gestion des Absences</h2>
        <Button className="bg-[#415444] hover:bg-[#415444]/90">Déclarer une absence</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {people.map((person) => (
          <Link href={`/absences/${person.id}`} key={person.id} className="block">
            <div className="relative overflow-hidden rounded-2xl h-[280px] group transition-all duration-300 hover:shadow-lg">
              <div className="absolute inset-0 bg-gradient-to-b from-blue-400/20 to-blue-600/80 z-10"></div>
              <Image src={person.image || "/placeholder.svg"} alt={person.name} fill className="object-cover z-0" />
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white z-20">
                <h3 className="text-2xl font-bold">{person.name}</h3>
                <p className="text-blue-100 mb-1">{person.department}</p>
                <p className="text-blue-100 text-sm">{person.absenceType}</p>
                <p className="text-blue-100 text-sm">
                  {new Date(person.startDate).toLocaleDateString()} - {new Date(person.endDate).toLocaleDateString()}
                </p>
                <div className="absolute bottom-6 right-6 bg-white/20 rounded-full p-2 backdrop-blur-sm group-hover:bg-white/30 transition-all">
                  <ChevronRight className="h-5 w-5 text-white" />
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
