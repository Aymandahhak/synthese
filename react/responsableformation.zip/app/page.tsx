"use client"

import { useState } from "react"
import { BarChart, Bell, Calendar, CheckSquare, FileText, Home, ListChecks, LogOut, Search, UserX } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { AbsencesPage } from "@/components/absences-page"
import { DocumentsPage } from "@/components/documents-page"
import { LogisticsPage } from "@/components/logistics-page"
import { PlanifierSessionForm } from "@/components/planifier-session-form"
import { ReportsPage } from "@/components/reports-page"
import { SessionsList } from "@/components/sessions-list"
import { ValidationSessions } from "@/components/validation-sessions"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Toaster } from "@/components/ui/toaster"
import { Badge } from "@/components/ui/badge"

export default function Component() {
  const [currentPage, setCurrentPage] = useState("dashboard")

  // Replace the popularItems array with formations data
  const formations = [
    {
      id: "1",
      name: "Introduction au Marketing Digital",
      status: "validated",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/The%20Best%20Media%20Tote%20Bags,%20Ranked.jpg-z2O2nGPSTrjey8xEM1cc5aTI2ggjXE.jpeg",
    },
    {
      id: "2",
      name: "Développement Web Avancé",
      status: "pending",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Index,%20Vanderbrand.jpg-Fv7HHkBaQgZe7HG3hbz5aojPoFRIuo.jpeg",
    },
    {
      id: "3",
      name: "Gestion de Projet Agile",
      status: "canceled",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/download%20(2).jpg-zbeT25jMphcVf4DmpAlTVsGALg88Zn.jpeg",
    },
    {
      id: "4",
      name: "Finance pour non-financiers",
      status: "validated",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/The%20Best%20Media%20Tote%20Bags,%20Ranked.jpg-z2O2nGPSTrjey8xEM1cc5aTI2ggjXE.jpeg",
    },
    {
      id: "5",
      name: "Techniques de vente avancées",
      status: "pending",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Index,%20Vanderbrand.jpg-Fv7HHkBaQgZe7HG3hbz5aojPoFRIuo.jpeg",
    },
    {
      id: "6",
      name: "Leadership et Management d'équipe",
      status: "validated",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/download%20(2).jpg-zbeT25jMphcVf4DmpAlTVsGALg88Zn.jpeg",
    },
  ]

  const renderContent = () => {
    switch (currentPage) {
      case "absences":
        return <AbsencesPage />
      case "planifier":
        return <PlanifierSessionForm />
      case "sessions":
        return <SessionsList />
      case "validation":
        return <ValidationSessions />
      case "documents":
        return <DocumentsPage />
      case "logistics":
        return <LogisticsPage />
      case "rapports":
        return <ReportsPage />
      case "dashboard":
      default:
        return (
          <>
            <div className="mb-12 grid grid-cols-2 gap-6">
              {/* Video Section with Créer Formation button */}
              <div className="relative overflow-hidden rounded-[24px] h-[250px] border border-[#415444]/10 group">
                <div className="absolute inset-0 bg-gradient-to-r from-[#415444]/80 to-[#415444]/60 z-10"></div>
                <div
                  className="absolute inset-0 bg-cover bg-center z-0"
                  style={{
                    backgroundImage:
                      "url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ajouterformation.PNG-ON8BZ4smTTxZO4RO27EG2GUXVcxLPH.png')",
                    backgroundSize: "cover",
                  }}
                ></div>
                <div className="absolute inset-0 flex flex-col items-center justify-center z-20 text-white text-center p-6">
                  <h3 className="text-3xl font-bold mb-2">Une nouvelle ère de formation</h3>
                  <p className="mb-6 max-w-md">
                    Créez des formations personnalisées pour répondre aux besoins spécifiques de votre équipe
                  </p>
                  <Button className="bg-[#415444] hover:bg-[#415444]/90 border-2 border-white">Créer Formation</Button>
                </div>
              </div>

              {/* Video Section with Planifier Session button */}
              <div className="relative overflow-hidden rounded-[24px] h-[250px] border border-[#415444]/10 group">
                <div className="absolute inset-0 bg-gradient-to-r from-[#338838]/70 to-[#338838]/50 z-10"></div>
                <div
                  className="absolute inset-0 bg-cover bg-center z-0"
                  style={{
                    backgroundImage:
                      "url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ajouterformation.PNG-ON8BZ4smTTxZO4RO27EG2GUXVcxLPH.png')",
                    backgroundSize: "cover",
                  }}
                ></div>
                <div className="absolute inset-0 flex flex-col items-center justify-center z-20 text-white text-center p-6">
                  <h3 className="text-3xl font-bold mb-2">Planifiez vos sessions</h3>
                  <p className="mb-6 max-w-md">Organisez et gérez efficacement vos sessions de formation</p>
                  <Button
                    className="bg-[#338838] hover:bg-[#338838]/90 border-2 border-white"
                    onClick={() => setCurrentPage("planifier")}
                  >
                    Planifier Session
                  </Button>
                </div>
              </div>
            </div>

            <div className="mb-8 flex items-center justify-between">
              <h3 className="text-2xl font-semibold">Liste des Formations</h3>
              <Button variant="link">Voir Tout</Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {formations.map((formation) => (
                <Card
                  key={formation.id}
                  className="group border-0 bg-[#e0e5ce] rounded-[24px] overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
                >
                  <CardHeader className="p-0 relative">
                    <div className="absolute inset-0 bg-black/40 opacity-0 transition-opacity group-hover:opacity-100 z-10" />
                    <Button className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 opacity-0 transform scale-95 transition-all group-hover:opacity-100 group-hover:scale-100 bg-white text-black hover:bg-white/90">
                      Quick View
                    </Button>
                    <Image
                      src={formation.image || "/placeholder.svg"}
                      alt={formation.name}
                      width={400}
                      height={400}
                      className="h-[280px] w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <div>
                      <h4 className="text-lg font-semibold mb-1 line-clamp-1">{formation.name}</h4>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Badge
                          variant="outline"
                          className={
                            formation.status === "validated"
                              ? "bg-green-100 text-green-800 hover:bg-green-100 border-green-200"
                              : formation.status === "pending"
                                ? "bg-yellow-100 text-yellow-800 hover:bg-yellow-100 border-yellow-200"
                                : "bg-red-100 text-red-800 hover:bg-red-100 border-red-200"
                          }
                        >
                          {formation.status === "validated"
                            ? "Validée"
                            : formation.status === "pending"
                              ? "En attente"
                              : "Annulée"}
                        </Badge>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="rounded-full hover:bg-[#415444] hover:text-white transition-colors"
                      >
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )
    }
  }

  return (
    <div className="flex min-h-screen bg-[#fcfdfd]">
      {/* Sidebar */}
      <aside className="w-64 border-r px-6 py-8">
        <div className="mb-8 flex justify-center">
          <div className="h-10 w-10 rounded-full bg-[#e0e5ce] flex items-center justify-center">
            <span className="text-[#415444] font-bold">TS</span>
          </div>
        </div>
        <nav className="space-y-6">
          <button
            onClick={() => setCurrentPage("dashboard")}
            className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 transition-colors ${
              currentPage === "dashboard" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <Home className="h-5 w-5" />
            Dashboard
          </button>
          <button
            onClick={() => setCurrentPage("planifier")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPage === "planifier" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <Calendar className="h-5 w-5" />
            Planifier Session
          </button>
          <button
            onClick={() => setCurrentPage("sessions")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPage === "sessions" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <ListChecks className="h-5 w-5" />
            Liste Sessions
          </button>
          <button
            onClick={() => setCurrentPage("validation")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPage === "validation" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <CheckSquare className="h-5 w-5" />
            Validation
          </button>
          <button
            onClick={() => setCurrentPage("absences")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPage === "absences" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <UserX className="h-5 w-5" />
            Absences
          </button>
          <button
            onClick={() => setCurrentPage("documents")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPage === "documents" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <FileText className="h-5 w-5" />
            Documents
          </button>
          <button
            onClick={() => setCurrentPage("logistics")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPage === "logistics" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <Home className="h-5 w-5" />
            Hébergements
          </button>
          <button
            onClick={() => setCurrentPage("rapports")}
            className={`flex w-full items-center gap-3 px-3 py-2 transition-colors ${
              currentPage === "rapports" ? "bg-[#e0e5ce] text-[#415444]" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <BarChart className="h-5 w-5" />
            Rapports
          </button>
          <button className="flex w-full items-center gap-3 px-3 py-2 text-red-500 transition-colors hover:text-red-600">
            <LogOut className="h-5 w-5" />
            Logout
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 px-8 py-8">
        <header className="mb-8">
          <div className="flex items-center justify-between border-b pb-4 mb-4">
            <div className="flex items-center gap-8">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/fs-OQzXWiKsdo0mSCzNZyZmZHXxrCi0Bp.png"
                alt="Fashion Store"
                width={150}
                height={40}
                className="h-10 w-auto"
              />
              <nav className="flex items-center gap-6">
                <Link href="#" className="font-medium text-[#415444]">
                  Home
                </Link>
                <Link href="#" className="font-medium text-gray-500 hover:text-[#415444]">
                  Profile
                </Link>
                <Link href="#" className="font-medium text-gray-500 hover:text-[#415444]">
                  About
                </Link>
              </nav>
            </div>
            <div className="flex items-center gap-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input className="w-64 pl-10" placeholder="Search destination" />
              </div>
              <Button size="icon" variant="ghost">
                <Bell className="h-5 w-5" />
              </Button>
              <Avatar className="w-10 h-10">
                <AvatarImage
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dd.jpg-482Kz4Ro7YXPgsZnttDFsQEmrWQnhG.jpeg"
                  alt="User avatar"
                />
                <AvatarFallback>NA</AvatarFallback>
              </Avatar>
            </div>
          </div>
          <div className="space-y-1">
            <h2 className="text-2xl font-semibold">
              Hi, Dollar! <span className="ml-1">👋</span>
            </h2>
            <p className="text-gray-500">Welcome Back</p>
          </div>
        </header>

        {renderContent()}
      </main>
      <Toaster />
    </div>
  )
}
